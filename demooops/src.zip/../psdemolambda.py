"""
functional programming
~~~~~~~~~~~~~~~~~~~~~~

syntax for the lambda function
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    lambda arg1, arg2,..... : expression
"""

power = lambda x, n: x ** n

print(power)
print(power(2, 3))
