items = [i for i in range(1, 11)]   # list comprehension
print(items)
print()


items = [i for i in range(1, 11) if not i % 2]   # compound list comprehension
print(items)
print()
