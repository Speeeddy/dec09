items = {hex(i) for i in range(1, 11)}   # set comprehension
print(items)
print()

items = {i: hex(i) for i in range(1, 11)}   # dict comprehension
print(items)
print()


