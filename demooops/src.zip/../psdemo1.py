items = 'pet'

li = iter(items)
print(li)
print(next(li))
print(next(li))
print(next(li))
print(next(li))


# iter protocol

# for item in items:  # iterator
#     print(item)

